import { Card } from "./UI.jsx";

const TILES = [
  { id: "portfolio",  icon: "📊", label: "Portfolio Case Studies",   desc: "Client investment portfolios with full allocation breakdowns" },
  { id: "equity",     icon: "📈", label: "Equity Research Reports",  desc: "Fundamental analysis & stock recommendations" },
  { id: "commentary", icon: "📰", label: "Market Commentary",        desc: "Monthly macro & equity market outlook" },
  { id: "etf",        icon: "⚖️", label: "ETF Comparison Projects",  desc: "Side-by-side fund analysis & selection guidance" },
  { id: "planning",   icon: "🏦", label: "Financial Planning Cases", desc: "Life-stage financial planning scenarios" },
  { id: "journal",    icon: "📓", label: "Trading Journal",          desc: "Documented trade rationale & lessons learned" },
];

export default function HomeSection({ onNav }) {
  return (
    <div>
      {/* Hero */}
      <div style={{
        padding: "64px 0 52px",
        borderBottom: "1px solid var(--border)",
        marginBottom: 48,
      }}>
        <div style={{
          display: "inline-block",
          background: "var(--purple-100)",
          color: "var(--purple-700)",
          fontSize: 11, fontWeight: 700,
          letterSpacing: "0.14em", textTransform: "uppercase",
          padding: "4px 12px", borderRadius: 20,
          marginBottom: 20, fontFamily: "var(--font-mono)",
        }}>
          Finance Professional · Vancouver, BC
        </div>

        <h1 style={{
          fontSize: 48, fontWeight: 700, margin: "0 0 14px",
          color: "var(--purple-950)", fontFamily: "var(--font-serif)",
          letterSpacing: "-0.03em", lineHeight: 1.1,
        }}>
          Your Name
        </h1>

        <p style={{
          fontSize: 16, color: "var(--purple-600)",
          margin: "0 0 18px", fontWeight: 600,
          letterSpacing: "0.01em",
        }}>
          Aspiring Wealth Advisor · Investment Analyst · Financial Markets Enthusiast
        </p>

        <p style={{
          fontSize: 15, color: "var(--text-muted)",
          margin: "0 0 32px", maxWidth: 580, lineHeight: 1.75,
        }}>
          Finance professional focused on evidence-based investment management, equity research,
          and comprehensive financial planning. This portfolio documents my analytical work across
          client portfolios, capital markets research, and financial planning cases.
        </p>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <button
            onClick={() => onNav("portfolio")}
            style={{
              background: "var(--purple-700)", color: "#fff",
              border: "none", borderRadius: 8,
              padding: "12px 26px", fontSize: 14,
              fontWeight: 600, cursor: "pointer",
              letterSpacing: "0.01em", fontFamily: "var(--font-sans)",
              transition: "background 0.15s",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "var(--purple-800)"}
            onMouseLeave={e => e.currentTarget.style.background = "var(--purple-700)"}
          >
            View My Work
          </button>
          <button
            style={{
              background: "transparent", color: "var(--purple-700)",
              border: "1.5px solid var(--purple-300)", borderRadius: 8,
              padding: "12px 26px", fontSize: 14,
              fontWeight: 600, cursor: "pointer",
              fontFamily: "var(--font-sans)", transition: "all 0.15s",
            }}
            onMouseEnter={e => { e.currentTarget.style.background = "var(--purple-50)"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
          >
            Download CV
          </button>
        </div>
      </div>

      {/* Market insight callout */}
      <div style={{
        background: "var(--purple-50)",
        border: "1px solid var(--purple-200)",
        borderLeft: "4px solid var(--purple-600)",
        borderRadius: 10, padding: "16px 20px",
        marginBottom: 44,
      }}>
        <div style={{
          fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase",
          color: "var(--purple-600)", fontWeight: 700, marginBottom: 7,
          fontFamily: "var(--font-mono)",
        }}>
          Market Insight · May 2025
        </div>
        <p style={{ margin: 0, fontSize: 14, color: "var(--purple-900)", lineHeight: 1.65 }}>
          BoC holds at 2.75%; TSX Financials +4.2% in May. Valuation dispersion between Canadian banks
          and US tech at 5-year highs — potential mean-reversion opportunity.{" "}
          <span
            style={{ cursor: "pointer", fontWeight: 700, color: "var(--purple-700)", textDecoration: "underline" }}
            onClick={() => onNav("commentary")}
          >
            Read full commentary →
          </span>
        </p>
      </div>

      {/* Section tiles */}
      <div style={{ marginBottom: 12 }}>
        <h3 style={{
          fontSize: 13, fontWeight: 700, textTransform: "uppercase",
          letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 16,
        }}>
          Portfolio Sections
        </h3>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
        {TILES.map(t => (
          <Card key={t.id} onClick={() => onNav(t.id)}>
            <div style={{ fontSize: 24, marginBottom: 12 }}>{t.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "var(--purple-900)", marginBottom: 6 }}>{t.label}</div>
            <div style={{ fontSize: 12, color: "var(--text-muted)", lineHeight: 1.55 }}>{t.desc}</div>
            <div style={{ marginTop: 16, fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>Open section →</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
