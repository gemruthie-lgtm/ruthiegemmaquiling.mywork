import { useState } from "react";
import { marketCommentary, etfComparisons, planningCases, tradingJournal } from "../data/index.js";
import { Badge, SectionHeader, Card, Modal, InfoRow } from "./UI.jsx";

// ─── MARKET COMMENTARY ────────────────────────────────────────────────────────
export function CommentarySection() {
  const [selected, setSelected] = useState(null);
  return (
    <div>
      <SectionHeader title="Monthly Market Commentary" subtitle="Macro & Markets" />
      <div style={{ display: "grid", gap: 16 }}>
        {marketCommentary.map(m => (
          <Card key={m.id} onClick={() => setSelected(m)}>
            <div style={{ fontSize: 11, color: "var(--purple-500)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "var(--font-mono)", marginBottom: 7 }}>{m.month}</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: "var(--purple-900)", marginBottom: 10, fontFamily: "var(--font-serif)" }}>{m.title}</div>
            <p style={{ margin: 0, fontSize: 13, color: "var(--text-muted)", lineHeight: 1.65 }}>{m.macro.substring(0, 155)}...</p>
            <div style={{ marginTop: 12, fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>Read full commentary →</div>
          </Card>
        ))}
      </div>

      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--purple-500)", fontWeight: 700, marginBottom: 6, fontFamily: "var(--font-mono)" }}>{selected.month} · Market Commentary</div>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 22px", fontFamily: "var(--font-serif)", color: "var(--purple-950)" }}>{selected.title}</h2>
          <InfoRow label="Macro Overview" value={selected.macro} />
          <InfoRow label="Equity Markets" value={selected.equities} />
          <InfoRow label="Investor Takeaway" value={selected.takeaway} />
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 10 }}>Key Events</div>
            <ul style={{ paddingLeft: 0 }}>
              {selected.keyEvents.map((e, i) => (
                <li key={i} style={{ fontSize: 14, marginBottom: 6, paddingLeft: 16, position: "relative", color: "var(--text)" }}>
                  <span style={{ position: "absolute", left: 0, color: "var(--purple-400)" }}>›</span>
                  {e}
                </li>
              ))}
            </ul>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── ETF COMPARISONS ──────────────────────────────────────────────────────────
export function ETFSection() {
  return (
    <div>
      <SectionHeader title="ETF Comparison Projects" subtitle="Fund Analysis" />
      <div style={{ display: "grid", gap: 28 }}>
        {etfComparisons.map(proj => (
          <Card key={proj.id} style={{ cursor: "default" }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: "var(--purple-900)", marginBottom: 6, fontFamily: "var(--font-serif)" }}>{proj.title}</div>
            <p style={{ margin: "0 0 20px", fontSize: 13, color: "var(--text-muted)", lineHeight: 1.65 }}>{proj.summary}</p>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                <thead>
                  <tr style={{ background: "var(--bg-subtle)" }}>
                    {["Fund", "Provider", "MER", "AUM", "YTD", "Currency", "Holdings", "Risk"].map(h => (
                      <th key={h} style={{
                        textAlign: "left", padding: "9px 11px",
                        fontWeight: 600, color: "var(--text-faint)",
                        fontSize: 11, textTransform: "uppercase",
                        letterSpacing: "0.06em",
                        borderBottom: "1px solid var(--border)",
                        whiteSpace: "nowrap",
                      }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {proj.etfs.map((etf, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid var(--border)" }}>
                      <td style={{ padding: "10px 11px", fontWeight: 700, fontFamily: "var(--font-mono)", color: "var(--purple-700)" }}>{etf.name}</td>
                      <td style={{ padding: "10px 11px", color: "var(--text-muted)" }}>{etf.provider}</td>
                      <td style={{ padding: "10px 11px", fontFamily: "var(--font-mono)" }}>{etf.mer}</td>
                      <td style={{ padding: "10px 11px", fontFamily: "var(--font-mono)" }}>{etf.aum}</td>
                      <td style={{ padding: "10px 11px", fontFamily: "var(--font-mono)", color: "#065f46", fontWeight: 600 }}>{etf.ytd}</td>
                      <td style={{ padding: "10px 11px", fontSize: 12 }}>{etf.currency}</td>
                      <td style={{ padding: "10px 11px" }}>{etf.holdings}</td>
                      <td style={{ padding: "10px 11px" }}><Badge color="gray">{etf.risk}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{
              marginTop: 18, padding: "14px 16px",
              background: "var(--purple-50)", borderRadius: 8,
              borderLeft: "3px solid var(--purple-500)",
            }}>
              <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--purple-600)", marginBottom: 5 }}>Conclusion</div>
              <p style={{ margin: 0, fontSize: 13, color: "var(--purple-900)", lineHeight: 1.65 }}>{proj.conclusion}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ─── FINANCIAL PLANNING ───────────────────────────────────────────────────────
export function PlanningSection() {
  const [selected, setSelected] = useState(null);
  return (
    <div>
      <SectionHeader title="Financial Planning Cases" subtitle="Comprehensive Planning" />
      <div style={{ display: "grid", gap: 16 }}>
        {planningCases.map(c => (
          <Card key={c.id} onClick={() => setSelected(c)}>
            <div style={{ display: "flex", gap: 16, alignItems: "flex-start" }}>
              <div style={{ fontSize: 30, flexShrink: 0 }}>{c.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 17, fontWeight: 700, color: "var(--purple-900)", marginBottom: 5, fontFamily: "var(--font-serif)" }}>{c.title}</div>
                <div style={{ fontSize: 13, color: "var(--text-muted)", marginBottom: 12 }}>{c.persona}</div>
                <div style={{ fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>View case study →</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--purple-500)", fontWeight: 700, marginBottom: 6, fontFamily: "var(--font-mono)" }}>Financial Planning Case</div>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 4px", fontFamily: "var(--font-serif)", color: "var(--purple-950)" }}>{selected.title}</h2>
          <p style={{ margin: "0 0 24px", color: "var(--text-muted)", fontSize: 13 }}>{selected.persona}</p>
          <InfoRow label="Income & Cash Flow" value={selected.income} />
          <InfoRow label="Savings Strategy" value={selected.savings} />
          <InfoRow label="Investment Allocation" value={selected.allocation} mono />
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 10 }}>Recommendations</div>
            <ul style={{ paddingLeft: 0 }}>
              {selected.recs.map((r, i) => (
                <li key={i} style={{ fontSize: 14, marginBottom: 8, paddingLeft: 18, position: "relative", lineHeight: 1.6, color: "var(--text)" }}>
                  <span style={{ position: "absolute", left: 0, color: "var(--purple-500)", fontWeight: 700 }}>›</span>
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── TRADING JOURNAL ──────────────────────────────────────────────────────────
export function JournalSection() {
  const [selected, setSelected] = useState(null);
  return (
    <div>
      <SectionHeader title="Trading Journal" subtitle="Trade Documentation" />
      <div style={{ display: "grid", gap: 16 }}>
        {tradingJournal.map(e => (
          <Card key={e.id} onClick={() => setSelected(e)}>
            <div style={{ fontSize: 11, color: "var(--purple-500)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "var(--font-mono)", marginBottom: 8 }}>{e.period}</div>
            <p style={{ margin: "0 0 12px", fontSize: 14, color: "var(--text)", lineHeight: 1.65 }}>{e.setup}</p>
            <div style={{ fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>Read full entry →</div>
          </Card>
        ))}
      </div>

      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--purple-500)", fontWeight: 700, marginBottom: 6, fontFamily: "var(--font-mono)" }}>Trading Journal · {selected.period}</div>
          <h2 style={{ fontSize: 22, fontWeight: 700, margin: "0 0 22px", fontFamily: "var(--font-serif)", color: "var(--purple-950)" }}>Trade Documentation</h2>
          <InfoRow label="Market Setup" value={selected.setup} />
          <InfoRow label="Trade Reasoning" value={selected.reasoning} />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 22 }}>
            <div style={{ background: "#d1fae5", borderRadius: 10, padding: "14px 16px" }}>
              <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "#065f46", marginBottom: 7 }}>✓ What Worked</div>
              <p style={{ margin: 0, fontSize: 13, color: "#064e3b", lineHeight: 1.65 }}>{selected.worked}</p>
            </div>
            <div style={{ background: "#fee2e2", borderRadius: 10, padding: "14px 16px" }}>
              <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "#991b1b", marginBottom: 7 }}>△ What Didn't</div>
              <p style={{ margin: 0, fontSize: 13, color: "#7f1d1d", lineHeight: 1.65 }}>{selected.didnt}</p>
            </div>
          </div>

          <div>
            <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 10 }}>Lessons Learned</div>
            <ul style={{ paddingLeft: 0 }}>
              {selected.lessons.map((l, i) => (
                <li key={i} style={{ fontSize: 14, marginBottom: 8, paddingLeft: 18, position: "relative", lineHeight: 1.6, color: "var(--text)" }}>
                  <span style={{ position: "absolute", left: 0, color: "var(--purple-500)", fontWeight: 700 }}>›</span>
                  {l}
                </li>
              ))}
            </ul>
          </div>
        </Modal>
      )}
    </div>
  );
}
