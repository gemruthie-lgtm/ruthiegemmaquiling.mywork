import { useState } from "react";
import { equityReports } from "../data/index.js";
import { Badge, SectionHeader, Card, Modal, InfoRow } from "./UI.jsx";

const recColor = { BUY: "green", HOLD: "amber", SELL: "red" };

export default function EquitySection() {
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <SectionHeader title="Equity Research Reports" subtitle="Fundamental Analysis" />
      <div style={{ display: "grid", gap: 16 }}>
        {equityReports.map(r => (
          <Card key={r.id} onClick={() => setSelected(r)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                  <span style={{ fontSize: 17, fontWeight: 700, color: "var(--purple-900)", fontFamily: "var(--font-serif)" }}>{r.company}</span>
                  <span style={{ fontSize: 12, color: "var(--text-faint)", fontFamily: "var(--font-mono)" }}>{r.ticker}</span>
                </div>
                <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{r.sector}</div>
              </div>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <Badge color={recColor[r.rec] || "gray"}>{r.rec}</Badge>
                <span style={{ fontSize: 14, fontWeight: 700, color: "var(--purple-700)", fontFamily: "var(--font-mono)" }}>PT {r.target}</span>
              </div>
            </div>
            <p style={{ margin: "12px 0 0", fontSize: 13, color: "var(--text-muted)", lineHeight: 1.65 }}>
              {r.summary.substring(0, 145)}...
            </p>
            <div style={{ marginTop: 12, fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>Read full report →</div>
          </Card>
        ))}
      </div>

      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10, marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--purple-500)", fontWeight: 700, marginBottom: 6, fontFamily: "var(--font-mono)" }}>Equity Research</div>
              <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 4px", fontFamily: "var(--font-serif)", color: "var(--purple-950)" }}>{selected.company}</h2>
              <span style={{ fontSize: 13, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>{selected.ticker} · {selected.sector}</span>
            </div>
            <div style={{ textAlign: "right" }}>
              <Badge color={recColor[selected.rec] || "gray"}>{selected.rec}</Badge>
              <div style={{ fontSize: 22, fontWeight: 700, color: "var(--purple-800)", marginTop: 8, fontFamily: "var(--font-serif)" }}>{selected.target}</div>
              <div style={{ fontSize: 11, color: "var(--text-faint)" }}>12-month price target</div>
            </div>
          </div>

          <InfoRow label="Investment Thesis" value={selected.summary} />
          <InfoRow label="Financial Summary" value={selected.financials} mono />
          <InfoRow label="Valuation" value={selected.valuation} />
          <InfoRow label="Key Risks" value={selected.risks} />
        </Modal>
      )}
    </div>
  );
}
