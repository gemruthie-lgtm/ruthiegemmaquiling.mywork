// ─── Badge ─────────────────────────────────────────────────────────────────────
export function Badge({ children, color = "purple" }) {
  const map = {
    purple: { bg: "#ede9fe", text: "#3d1c8a" },
    green:  { bg: "#d1fae5", text: "#065f46" },
    amber:  { bg: "#fef3c7", text: "#92400e" },
    red:    { bg: "#fee2e2", text: "#991b1b" },
    gray:   { bg: "#f3f4f6", text: "#374151" },
  };
  const c = map[color] || map.purple;
  return (
    <span style={{
      background: c.bg, color: c.text,
      fontSize: 11, fontWeight: 700,
      padding: "3px 9px", borderRadius: 4,
      letterSpacing: "0.06em", textTransform: "uppercase",
      fontFamily: "var(--font-mono)",
    }}>
      {children}
    </span>
  );
}

// ─── SectionHeader ─────────────────────────────────────────────────────────────
export function SectionHeader({ title, subtitle }) {
  return (
    <div style={{ marginBottom: 36, paddingBottom: 20, borderBottom: "1px solid var(--border)" }}>
      <div style={{
        fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase",
        color: "var(--purple-600)", fontWeight: 700, marginBottom: 10,
        fontFamily: "var(--font-mono)",
      }}>
        {subtitle}
      </div>
      <h2 style={{
        fontSize: 28, fontWeight: 700, margin: 0,
        color: "var(--purple-900)", fontFamily: "var(--font-serif)",
        letterSpacing: "-0.02em",
      }}>
        {title}
      </h2>
    </div>
  );
}

// ─── Card ──────────────────────────────────────────────────────────────────────
export function Card({ children, style = {}, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: "#fff",
        border: "1px solid var(--border)",
        borderRadius: 12,
        padding: "22px 24px",
        cursor: onClick ? "pointer" : "default",
        transition: "border-color 0.2s, box-shadow 0.2s, transform 0.15s",
        ...style,
      }}
      onMouseEnter={e => {
        if (!onClick) return;
        e.currentTarget.style.borderColor = "var(--purple-400)";
        e.currentTarget.style.boxShadow = "0 4px 20px rgba(107,61,212,0.1)";
        e.currentTarget.style.transform = "translateY(-1px)";
      }}
      onMouseLeave={e => {
        if (!onClick) return;
        e.currentTarget.style.borderColor = "var(--border)";
        e.currentTarget.style.boxShadow = "none";
        e.currentTarget.style.transform = "translateY(0)";
      }}
    >
      {children}
    </div>
  );
}

// ─── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ onClose, children }) {
  return (
    <div
      style={{
        position: "fixed", inset: 0,
        background: "rgba(26,10,61,0.55)",
        zIndex: 1000, display: "flex",
        alignItems: "flex-start", justifyContent: "center",
        padding: "40px 16px", overflowY: "auto",
      }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div style={{
        background: "#fff", borderRadius: 16,
        width: "100%", maxWidth: 700,
        padding: "36px 40px", position: "relative",
        boxShadow: "0 20px 60px rgba(26,10,61,0.2)",
      }}>
        <button
          onClick={onClose}
          style={{
            position: "absolute", top: 18, right: 20,
            background: "var(--bg-subtle)", border: "none",
            width: 32, height: 32, borderRadius: 8,
            fontSize: 18, cursor: "pointer",
            color: "var(--purple-700)", lineHeight: 1,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          ×
        </button>
        {children}
      </div>
    </div>
  );
}

// ─── AllocationBar ─────────────────────────────────────────────────────────────
export function AllocationBar({ allocation }) {
  const colors = ["#5228b0","#6b3dd4","#8b5cf6","#a78bfa","#c4b5fd","#ddd6fe"];
  return (
    <div style={{ marginTop: 14 }}>
      <div style={{ display: "flex", height: 8, borderRadius: 6, overflow: "hidden", gap: 2 }}>
        {allocation.map((seg, i) => (
          <div key={i} style={{
            width: `${seg.pct}%`,
            background: colors[i % colors.length],
            borderRadius: i === 0 ? "6px 0 0 6px" : i === allocation.length - 1 ? "0 6px 6px 0" : 0,
          }} />
        ))}
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 18px", marginTop: 10 }}>
        {allocation.map((seg, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "var(--text-muted)" }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: colors[i % colors.length], flexShrink: 0 }} />
            {seg.label} — {seg.pct}%
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── InfoRow ──────────────────────────────────────────────────────────────────
export function InfoRow({ label, value, mono = false }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{
        fontSize: 11, fontWeight: 700, textTransform: "uppercase",
        letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 5,
      }}>
        {label}
      </div>
      <p style={{
        margin: 0, fontSize: 14, lineHeight: 1.7,
        color: "var(--text)", fontFamily: mono ? "var(--font-mono)" : "var(--font-sans)",
      }}>
        {value}
      </p>
    </div>
  );
}

// ─── StatGrid ─────────────────────────────────────────────────────────────────
export function StatGrid({ stats }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${stats.length}, 1fr)`, gap: 10, marginBottom: 22 }}>
      {stats.map(([k, v]) => (
        <div key={k} style={{
          background: "var(--bg-subtle)", borderRadius: 10,
          padding: "12px 14px", border: "1px solid var(--border)",
        }}>
          <div style={{ fontSize: 11, color: "var(--text-faint)", marginBottom: 4 }}>{k}</div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "var(--purple-800)" }}>{v}</div>
        </div>
      ))}
    </div>
  );
}
