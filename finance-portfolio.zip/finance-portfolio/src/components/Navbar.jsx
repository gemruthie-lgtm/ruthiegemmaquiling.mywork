const SECTIONS = [
  { id: "home",        label: "Home" },
  { id: "portfolio",   label: "Portfolio" },
  { id: "equity",      label: "Equity Research" },
  { id: "commentary",  label: "Commentary" },
  { id: "etf",         label: "ETFs" },
  { id: "planning",    label: "Planning" },
  { id: "journal",     label: "Journal" },
];

export default function Navbar({ active, onNav }) {
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 100,
      background: "rgba(255,255,255,0.95)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--border)",
      padding: "0 32px",
    }}>
      <div style={{
        maxWidth: 900, margin: "0 auto",
        display: "flex", alignItems: "center",
        justifyContent: "space-between", height: 58,
        gap: 16,
      }}>
        {/* Logo */}
        <div
          onClick={() => onNav("home")}
          style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}
        >
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: "linear-gradient(135deg, var(--purple-700), var(--purple-500))",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, color: "#fff", fontWeight: 700, fontFamily: "var(--font-serif)",
          }}>
            YN
          </div>
          <span style={{
            fontFamily: "var(--font-serif)", fontWeight: 700,
            fontSize: 15, color: "var(--purple-900)", letterSpacing: "-0.01em",
          }}>
            Your Name
          </span>
        </div>

        {/* Nav links */}
        <div style={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
          {SECTIONS.map(s => (
            <button
              key={s.id}
              onClick={() => onNav(s.id)}
              style={{
                background: active === s.id ? "var(--purple-700)" : "transparent",
                color: active === s.id ? "#fff" : "var(--text-muted)",
                border: "none", borderRadius: 7,
                padding: "5px 12px", fontSize: 13,
                fontWeight: active === s.id ? 600 : 400,
                cursor: "pointer", transition: "all 0.15s",
                fontFamily: "var(--font-sans)",
              }}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
