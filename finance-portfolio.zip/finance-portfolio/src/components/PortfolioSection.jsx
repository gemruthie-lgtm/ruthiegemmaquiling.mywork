import { useState } from "react";
import { portfolioCases } from "../data/index.js";
import { Badge, SectionHeader, Card, Modal, AllocationBar, InfoRow, StatGrid } from "./UI.jsx";

const riskColor = { Conservative: "purple", Moderate: "amber", Aggressive: "red" };

export default function PortfolioSection() {
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <SectionHeader title="Portfolio Case Studies" subtitle="Investment Management" />
      <div style={{ display: "grid", gap: 16 }}>
        {portfolioCases.map(c => (
          <Card key={c.id} onClick={() => setSelected(c)}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
              <div>
                <div style={{ fontSize: 17, fontWeight: 700, color: "var(--purple-900)", marginBottom: 4, fontFamily: "var(--font-serif)" }}>{c.title}</div>
                <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{c.client}</div>
              </div>
              <Badge color={riskColor[c.risk] || "gray"}>{c.risk} Risk</Badge>
            </div>
            <AllocationBar allocation={c.allocation} />
            <div style={{ marginTop: 14, fontSize: 12, color: "var(--purple-600)", fontWeight: 600 }}>View full case study →</div>
          </Card>
        ))}
      </div>

      {selected && (
        <Modal onClose={() => setSelected(null)}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--purple-500)", fontWeight: 700, marginBottom: 8, fontFamily: "var(--font-mono)" }}>Case Study</div>
          <h2 style={{ fontSize: 24, fontWeight: 700, margin: "0 0 4px", fontFamily: "var(--font-serif)", color: "var(--purple-950)" }}>{selected.title}</h2>
          <p style={{ margin: "0 0 22px", color: "var(--text-muted)", fontSize: 14 }}>{selected.client}</p>

          <StatGrid stats={[["Age", selected.age], ["Goals", selected.goals], ["Risk Profile", selected.risk]]} />

          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 8 }}>Asset Allocation</div>
            <AllocationBar allocation={selected.allocation} />
          </div>

          <InfoRow label="Investment Strategy" value={selected.strategy} />

          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", marginBottom: 8 }}>Instruments Used</div>
            <ul style={{ paddingLeft: 0 }}>
              {selected.instruments.map((ins, i) => (
                <li key={i} style={{ fontSize: 13, fontFamily: "var(--font-mono)", color: "var(--purple-800)", marginBottom: 5, paddingLeft: 14, position: "relative" }}>
                  <span style={{ position: "absolute", left: 0, color: "var(--purple-400)" }}>›</span>
                  {ins}
                </li>
              ))}
            </ul>
          </div>

          <InfoRow label="Key Risks" value={selected.risks} />
        </Modal>
      )}
    </div>
  );
}
