import { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import HomeSection from "./components/HomeSection.jsx";
import PortfolioSection from "./components/PortfolioSection.jsx";
import EquitySection from "./components/EquitySection.jsx";
import { CommentarySection, ETFSection, PlanningSection, JournalSection } from "./components/Sections.jsx";

export default function App() {
  const [active, setActive] = useState("home");

  const nav = (id) => {
    setActive(id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Navbar active={active} onNav={nav} />

      <main style={{ maxWidth: 900, margin: "0 auto", padding: "44px 28px 100px" }}>
        {active === "home"        && <HomeSection onNav={nav} />}
        {active === "portfolio"   && <PortfolioSection />}
        {active === "equity"      && <EquitySection />}
        {active === "commentary"  && <CommentarySection />}
        {active === "etf"         && <ETFSection />}
        {active === "planning"    && <PlanningSection />}
        {active === "journal"     && <JournalSection />}
      </main>

      <footer style={{
        borderTop: "1px solid var(--border)",
        padding: "24px 28px",
        textAlign: "center",
        background: "var(--bg-soft)",
      }}>
        <p style={{ margin: 0, fontSize: 12, color: "var(--text-faint)", letterSpacing: "0.04em" }}>
          © 2025 Your Name · Finance Portfolio · Built for wealth management & investment analyst recruitment
        </p>
        <p style={{ margin: "6px 0 0", fontSize: 11, color: "var(--text-faint)" }}>
          All analysis is for educational and portfolio demonstration purposes only. Not financial advice.
        </p>
      </footer>
    </div>
  );
}
