// ─── PORTFOLIO CASE STUDIES ───────────────────────────────────────────────────
export const portfolioCases = [
  {
    id: 1,
    title: "Conservative Retiree Portfolio",
    client: "68-year-old retired teacher",
    age: 68,
    goals: "Capital preservation & income",
    risk: "Conservative",
    allocation: [
      { label: "Fixed Income", pct: 55 },
      { label: "Canadian Equity", pct: 20 },
      { label: "International Equity", pct: 10 },
      { label: "Cash & GICs", pct: 15 },
    ],
    strategy:
      "Income-first approach with laddered bond portfolio and dividend-focused equities. Designed to withstand market drawdowns while generating ~4% annual income.",
    instruments: [
      "XBB.TO — iShares Core Canadian Bond ETF",
      "ZDV.TO — BMO Canadian Dividend ETF",
      "VDY.TO — Vanguard FTSE CDN High Dividend Yield",
      "GICs — 1, 2, 3-year ladder",
    ],
    risks:
      "Inflation erosion of purchasing power; interest rate risk on bond duration; longevity risk beyond 20-year horizon.",
  },
  {
    id: 2,
    title: "Aggressive Growth — Young Professional",
    client: "29-year-old software engineer",
    age: 29,
    goals: "Long-term wealth accumulation",
    risk: "Aggressive",
    allocation: [
      { label: "US Equity", pct: 40 },
      { label: "Canadian Equity", pct: 25 },
      { label: "International Developed", pct: 20 },
      { label: "Emerging Markets", pct: 10 },
      { label: "Alternatives", pct: 5 },
    ],
    strategy:
      "All-equity growth mandate leveraging long time horizon. Dollar-cost averaging into low-cost index funds supplemented by satellite positions in high-conviction sectors.",
    instruments: [
      "VFV.TO — Vanguard S&P 500 Index ETF",
      "XIU.TO — iShares S&P/TSX 60 ETF",
      "XEF.TO — iShares MSCI EAFE IMI Index ETF",
      "XEC.TO — iShares MSCI Emerging Markets ETF",
    ],
    risks:
      "High short-term volatility; concentration in North American markets; behavioural risk during drawdowns.",
  },
  {
    id: 3,
    title: "Balanced Portfolio — Pre-Retiree",
    client: "54-year-old business owner",
    age: 54,
    goals: "Transition to retirement in 10 years",
    risk: "Moderate",
    allocation: [
      { label: "Canadian Equity", pct: 30 },
      { label: "US & Intl Equity", pct: 30 },
      { label: "Fixed Income", pct: 30 },
      { label: "Real Assets", pct: 10 },
    ],
    strategy:
      "Classic 60/40 evolving toward 50/50 over the decade. Focus on dividend growers and investment-grade bonds. Annual rebalancing with tax-loss harvesting.",
    instruments: [
      "XBAL.TO — iShares Core Balanced ETF Portfolio",
      "ZRE.TO — BMO Equal Weight REITs ETF",
      "VAB.TO — Vanguard Canadian Aggregate Bond ETF",
      "CDZ.TO — iShares CDN Dividend Aristocrats ETF",
    ],
    risks:
      "Sequence-of-returns risk; real estate market exposure; currency risk on international allocation.",
  },
];

// ─── EQUITY RESEARCH REPORTS ──────────────────────────────────────────────────
export const equityReports = [
  {
    id: 1,
    company: "Royal Bank of Canada",
    ticker: "RY.TO",
    sector: "Financials",
    rec: "BUY",
    target: "$168.00",
    thesis: "Bull",
    summary:
      "RBC's diversified revenue mix — spanning capital markets, wealth management, and retail banking — positions it as the most resilient of the Big Six. HSBC Canada acquisition adds ~$60B in AUM and expands commercial lending.",
    financials:
      "FY2024 Net Income: $16.2B | ROE: 14.8% | CET1 Ratio: 12.8% | Dividend Yield: 4.1%",
    valuation:
      "Trading at 11.2x forward P/E vs. 10-year average of 12.4x. Price-to-book of 1.7x represents a 15% discount to historical mean. DCF implies $171 fair value.",
    risks:
      "Canadian housing market correction; regulatory capital increases; PCLs rising in consumer segment.",
  },
  {
    id: 2,
    company: "Apple Inc.",
    ticker: "AAPL",
    sector: "Technology",
    rec: "HOLD",
    target: "$195.00",
    thesis: "Neutral",
    summary:
      "Services segment (30%+ gross margins) increasingly offsets hardware cyclicality. However, China revenue headwinds and saturation in premium smartphone market cap near-term upside.",
    financials:
      "FY2024 Revenue: $391B | Operating Margin: 31.5% | Free Cash Flow: $107B | EPS: $6.57",
    valuation:
      "At 28x forward earnings, Apple commands a premium to the S&P 500. PEG ratio of 2.4x suggests fair value, not undervaluation. Buyback yield of ~3.5% provides floor.",
    risks:
      "US-China trade escalation; antitrust actions on App Store; generative AI monetization timeline.",
  },
  {
    id: 3,
    company: "Brookfield Corporation",
    ticker: "BN.TO",
    sector: "Financials / Alt. Assets",
    rec: "BUY",
    target: "$72.00",
    thesis: "Bull",
    summary:
      "Brookfield's insurance-led capital flywheel combined with a $1T+ AUM target by 2028 creates a compelling compounder. Fee-related earnings visibility is underappreciated by the market.",
    financials:
      "FY2024 Distributable Earnings: $4.8B | AUM: $925B | Fee Revenue: $2.3B | Book Value/Share: $49.20",
    valuation:
      "Sum-of-parts: Asset Management (25x FRE) + Invested Capital at 0.85x BV + Insurance at 1.1x. Combined intrinsic value $68–74. 15% discount to NAV.",
    risks:
      "Alternative asset fundraising environment; rate sensitivity on insurance float; complexity discount persistent.",
  },
];

// ─── MARKET COMMENTARY ────────────────────────────────────────────────────────
export const marketCommentary = [
  {
    id: 1,
    month: "May 2025",
    title: "Rate Cuts Deferred — Equities Resilient",
    macro:
      "The Bank of Canada held rates at 2.75% amid sticky core inflation (3.1% CPI). The Fed signalled a patient stance, pushing market expectations for the first cut to Q4 2025. Bond markets re-priced duration risk, with the 10-year Canada yield settling near 3.45%.",
    equities:
      "TSX Composite gained 2.1% in May, led by Financials (+4.2%) and Energy (+3.0%). Technology lagged (-1.8%) as rate sensitivity weighed. The S&P 500 returned 1.4% with narrow breadth.",
    keyEvents: [
      "BoC Rate Decision — Hold at 2.75%",
      "Q1 GDP: +2.3% annualized (beat expectations)",
      "US-Canada tariff framework — partial resolution",
      "Crude WTI average: $78.40/bbl",
    ],
    takeaway:
      "Maintain overweight in Canadian Financials and Energy. Reduce duration in fixed income. Selective exposure to US mega-cap tech through diversified ETFs rather than individual names.",
  },
  {
    id: 2,
    month: "April 2025",
    title: "Volatility Spike — Defensive Rotation",
    macro:
      "Tariff uncertainty drove a 15% intraday VIX spike. Credit spreads widened modestly (IG +18bps). Safe-haven flows lifted gold to $3,200/oz. CAD weakened to 0.715 USD on commodity demand concerns.",
    equities:
      "TSX fell 3.2% — worst month since October 2023. Consumer Discretionary (-7.1%) and Materials (-5.4%) led losses. Utilities (+1.2%) and REITs (+0.8%) outperformed defensively.",
    keyEvents: [
      "US tariff announcements — broad escalation",
      "BoC emergency liquidity operations",
      "Q4 2024 Earnings: 68% beat EPS estimates",
      "Bank of Japan surprise rate hold",
    ],
    takeaway:
      "Volatility creates opportunity. Trim cash drag and deploy incrementally into quality cyclicals. Keep fixed income allocation stable — bonds performed their hedge function.",
  },
];

// ─── ETF COMPARISONS ──────────────────────────────────────────────────────────
export const etfComparisons = [
  {
    id: 1,
    title: "Canadian S&P 500 Exposure: VFV vs. XSP vs. ZSP",
    summary:
      "Comparing the three dominant S&P 500 ETFs on Canadian exchanges for a registered account investor.",
    etfs: [
      { name: "VFV.TO", provider: "Vanguard", mer: "0.09%", aum: "$12.4B", ytd: "+8.2%", currency: "Unhedged (CAD)", holdings: "504 stocks", risk: "High" },
      { name: "XSP.TO", provider: "BlackRock", mer: "0.10%", aum: "$9.8B", ytd: "+7.6%", currency: "Hedged (CAD)", holdings: "504 stocks", risk: "High" },
      { name: "ZSP.TO", provider: "BMO", mer: "0.09%", aum: "$8.1B", ytd: "+8.1%", currency: "Unhedged (CAD)", holdings: "503 stocks", risk: "High" },
    ],
    conclusion:
      "For long-term investors comfortable with USD/CAD fluctuation, VFV and ZSP offer equivalent low-cost exposure. XSP suits investors seeking currency certainty at minimal additional cost (1bp).",
  },
  {
    id: 2,
    title: "Canadian Bond ETFs: VAB vs. ZAG vs. XBB",
    summary:
      "Core fixed income building block comparison for the bond sleeve of a diversified portfolio.",
    etfs: [
      { name: "VAB.TO", provider: "Vanguard", mer: "0.09%", aum: "$4.2B", ytd: "+1.4%", currency: "CAD", holdings: "~1,200 bonds", risk: "Low–Med" },
      { name: "ZAG.TO", provider: "BMO", mer: "0.09%", aum: "$6.8B", ytd: "+1.5%", currency: "CAD", holdings: "~750 bonds", risk: "Low–Med" },
      { name: "XBB.TO", provider: "BlackRock", mer: "0.10%", aum: "$3.1B", ytd: "+1.3%", currency: "CAD", holdings: "~1,500 bonds", risk: "Low–Med" },
    ],
    conclusion:
      "ZAG holds the most assets with tightest bid-ask spreads. VAB and XBB offer marginally broader diversification. All three are suitable core fixed income holdings.",
  },
];

// ─── FINANCIAL PLANNING CASES ─────────────────────────────────────────────────
export const planningCases = [
  {
    id: 1,
    icon: "🎓",
    title: "New Graduate Starting Career",
    persona: "23-year-old, $62,000 salary, $28,000 student debt",
    income: "$62,000 gross / ~$46,500 net | Monthly take-home: ~$3,875",
    savings:
      "Prioritize FHSA ($8,000/yr) for home purchase goal. Contribute to employer RRSP match first (free money). Build $10,000 emergency fund in HISA over 12 months.",
    allocation:
      "FHSA: XBAL.TO (balanced, auto-rebalancing) | RRSP: VFV.TO + XIC.TO | Emergency: EQ Bank HISA @ 3.5%",
    recs: [
      "Eliminate student debt over 3 years — guaranteed 5.5% return",
      "Max employer RRSP match before anything else",
      "Avoid complex products — simplicity compounds",
      "Automate all contributions on paydate",
    ],
  },
  {
    id: 2,
    icon: "🏠",
    title: "Young Professional Saving for First Home",
    persona: "31-year-old couple, combined $175,000, renting in Vancouver",
    income: "$175,000 combined gross / ~$128,000 net | Monthly take-home: ~$10,667",
    savings:
      "Target: $200,000 down payment in 5 years. Required monthly savings: $2,800. Use both FHSA accounts ($16,000/yr combined) plus RRSP HBP ($70,000 combined).",
    allocation:
      "FHSA: ZAG (50%) + XIU (50%) | RRSP HBP: XBAL.TO | Surplus: Non-reg 2-year GIC ladder",
    recs: [
      "FHSA first — tax deduction + tax-free growth",
      "Don't overreach on house price — stress test at +2%",
      "Avoid locking savings in illiquid instruments",
      "Revisit allocation annually as purchase date approaches",
    ],
  },
  {
    id: 3,
    icon: "🌅",
    title: "Retiree Income Strategy",
    persona: "67-year-old, $800,000 portfolio, CPP + OAS starting",
    income: "CPP: $1,100/mo | OAS: $700/mo | Required from portfolio: $2,200/mo (3.3% withdrawal rate)",
    savings:
      "Sustainable at 3.3% withdrawal — within historical safe rates. Prioritize RRSP/RRIF drawdown for tax efficiency. Consider delaying OAS to 70 ($1,025/mo vs $700 at 65).",
    allocation:
      "RRIF: ZDV (30%) + VAB (40%) + ZRE (20%) + Cash (10%) | TFSA: VFV — last to draw",
    recs: [
      "RRIF minimum withdrawal optimization begins at 72",
      "TFSA as estate planning vehicle — grow tax-free",
      "Review CPP splitting with spouse annually",
      "Annual bucket review: 2-yr cash buffer always maintained",
    ],
  },
];

// ─── TRADING JOURNAL ──────────────────────────────────────────────────────────
export const tradingJournal = [
  {
    id: 1,
    period: "Week of May 5, 2025",
    setup:
      "Tariff-driven selloff created oversold conditions in Canadian bank stocks (RSI < 28). Thesis: regulatory clarity typically follows policy announcements within 2–3 weeks.",
    reasoning:
      "Opened a position in RY.TO at $148.20 — 8% below fair value estimate. Used a 5% trailing stop. Sized at 4% of portfolio (within single-name risk parameters).",
    worked:
      "Regulatory clarity arrived May 12. RY.TO recovered to $154.40 (+4.2%) over 7 trading days. Stop was not triggered.",
    didnt:
      "Entry was 2 days early — stock dipped to $145.80 before reversing. Waiting for price confirmation (5-day EMA reclaim) would have improved average cost.",
    lessons: [
      "Patience in confirmation often improves average cost",
      "News-driven selloffs in quality names are opportunity — but timing is uncertain",
      "Position sizing discipline prevented overconcentration",
    ],
  },
  {
    id: 2,
    period: "Week of April 14, 2025",
    setup:
      "Volatility spike (VIX > 28) triggered a systematic rebalancing signal. Portfolio had drifted to 55% equities from target 60% due to equity drawdown.",
    reasoning:
      "Executed rules-based rebalance — added to XIU.TO and VFV.TO, trimmed ZAG.TO. No market timing — purely mechanical rebalancing at ±5% band breach.",
    worked:
      "Rebalance locked in bond gains and added equity at cyclical lows. Equities subsequently recovered — mechanical approach outperformed discretionary 'wait and see'.",
    didnt:
      "No errors — process worked as designed. Execution over 3 trading days minimized market impact.",
    lessons: [
      "Rules-based rebalancing removes emotional decision-making",
      "Rebalancing IS the strategy — not a disruption to it",
      "Document every trade; accountability improves discipline",
    ],
  },
];
